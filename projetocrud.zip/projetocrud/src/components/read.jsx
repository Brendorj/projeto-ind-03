import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Table, Button, TableCell } from 'semantic-ui-react';

export default function Read() {
    const [APIData, setAPIData] = useState([]);
    useEffect(() => {
        axios.get(`https://63780b0a0992902a2515b79f.mockapi.io/usuario`)
            .then((response) => {
                console.log(response.data)
                setAPIData(response.data);
            })
    }, []);

    const setData = (data) => {
        let { id, firstName, lastName, checkbox } = data;
        localStorage.setItem('ID', id);
        localStorage.setItem('First Name', firstName);
        localStorage.setItem('Last Name', lastName);
        localStorage.setItem('Checkbox Value', checkbox)
    }

    const onDelete = (id) => {
        if (window.confirm("Confirma Exclusão?")) {
            axios.delete(`https://63780b0a0992902a2515b79f.mockapi.io/usuario/${id}`)
        }
    }

    return (
        <div>
            <Table singleLine>

                <Table.Header>
                    <Table.Row>
                        <Table.HeaderCell>Nome</Table.HeaderCell>
                        <Table.HeaderCell>Sobrenome</Table.HeaderCell>
                        <Table.HeaderCell>Checkbox</Table.HeaderCell>
                        <Table.HeaderCell>Ação</Table.HeaderCell>
                    </Table.Row>
                </Table.Header>

                <Table.Body>
                    {APIData.map((data) => {
                        return (
                            <Table.Row>
                                <Table.Cell>{data.firstName}</Table.Cell>
                                <Table.Cell>{data.lastName}</Table.Cell>
                                <Table.Cell>{data.checkbox ? 'Aceito' : 'Não Aceito'}</Table.Cell>
                                <TableCell>
                                <Button onClick={() => onDelete(data.id)}>Remover</Button>
                                </TableCell>
                            </Table.Row>
                        )
                    })}
                </Table.Body>
            </Table>
        </div>
    )
}